
// GCS Shared Components — KL-GCS PICODE Design Reference
// Theme matches Theme.qml exactly

const T = {
  bgPrimary:   "#0b0d10",
  bgSecondary: "#12161b",
  bgElevated:  "#1a2027",
  textPrimary:   "#e8edf2",
  textSecondary: "#8f9baa",
  textDisabled:  "#5c6673",
  accentYellow: "#e3d049",
  accentBlue:   "#7fd6ff",
  statusOk:   "#62d48f",
  statusWarn: "#ffb347",
  statusCrit: "#ff5b5b",
  border: "#2a313a",
  statusBarH: 40,
  navBarH: 72,
  screenW: 1024,
  screenH: 600,
};

// ── StatusDot ──────────────────────────────────────────────────────────────
function StatusDot({ status = "ok", size = 8 }) {
  const color = status === "ok" ? T.statusOk : status === "warn" ? T.statusWarn : status === "crit" ? T.statusCrit : T.textDisabled;
  return (
    <span style={{
      display: "inline-block",
      width: size, height: size,
      borderRadius: "50%",
      background: color,
      flexShrink: 0,
      boxShadow: `0 0 ${size}px ${color}88`,
    }} />
  );
}

// ── DataCard ──────────────────────────────────────────────────────────────
function DataCard({ label, value, unit, sub, status, accent, wide, children, style }) {
  const accentColor = accent === "yellow" ? T.accentYellow : accent === "blue" ? T.accentBlue : null;
  return (
    <div style={{
      background: T.bgElevated,
      border: `1px solid ${T.border}`,
      borderRadius: 4,
      padding: "10px 14px",
      display: "flex",
      flexDirection: "column",
      gap: 4,
      minWidth: wide ? 160 : 100,
      ...style,
    }}>
      <div style={{ fontSize: 10, color: T.textSecondary, letterSpacing: "0.08em", textTransform: "uppercase", fontFamily: "monospace" }}>
        {label}
      </div>
      {value !== undefined && (
        <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
          <span style={{ fontSize: 28, fontWeight: 600, color: accentColor || (status === "crit" ? T.statusCrit : status === "warn" ? T.statusWarn : status === "ok" ? T.statusOk : T.textPrimary), fontFamily: "monospace", lineHeight: 1 }}>
            {value}
          </span>
          {unit && <span style={{ fontSize: 11, color: T.textSecondary, fontFamily: "monospace" }}>{unit}</span>}
        </div>
      )}
      {sub && <div style={{ fontSize: 11, color: T.textSecondary, fontFamily: "monospace" }}>{sub}</div>}
      {children}
    </div>
  );
}

// ── SmallDataCard ──────────────────────────────────────────────────────────
function SmallDataCard({ label, value, unit, status, style }) {
  const valColor = status === "crit" ? T.statusCrit : status === "warn" ? T.statusWarn : status === "ok" ? T.statusOk : T.textPrimary;
  return (
    <div style={{
      background: T.bgElevated,
      border: `1px solid ${T.border}`,
      borderRadius: 4,
      padding: "8px 12px",
      display: "flex",
      flexDirection: "column",
      gap: 3,
      ...style,
    }}>
      <div style={{ fontSize: 10, color: T.textSecondary, letterSpacing: "0.08em", textTransform: "uppercase", fontFamily: "monospace" }}>{label}</div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 3 }}>
        <span style={{ fontSize: 18, fontWeight: 600, color: valColor, fontFamily: "monospace", lineHeight: 1 }}>{value}</span>
        {unit && <span style={{ fontSize: 10, color: T.textSecondary, fontFamily: "monospace" }}>{unit}</span>}
      </div>
    </div>
  );
}

// ── BigButton ──────────────────────────────────────────────────────────────
function BigButton({ label, sub, active, destructive, disabled, onClick, style }) {
  const [hov, setHov] = React.useState(false);
  const bg = destructive
    ? (active ? T.statusCrit : hov ? "#2a1515" : T.bgElevated)
    : (active ? T.accentYellow : hov ? "#21272e" : T.bgElevated);
  const textColor = active ? (destructive ? "#fff" : T.bgPrimary) : (destructive ? T.statusCrit : T.textPrimary);
  const borderColor = active ? (destructive ? T.statusCrit : T.accentYellow) : (hov ? (destructive ? T.statusCrit : T.accentYellow) : T.border);
  return (
    <button
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: bg,
        border: `1px solid ${borderColor}`,
        borderRadius: 4,
        color: textColor,
        fontSize: 13,
        fontWeight: 700,
        fontFamily: "monospace",
        letterSpacing: "0.08em",
        padding: "0 16px",
        minHeight: 48,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.4 : 1,
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        gap: 2,
        transition: "all 0.12s",
        ...style,
      }}
    >
      <span>{label}</span>
      {sub && <span style={{ fontSize: 10, color: active ? (destructive ? "rgba(255,255,255,0.7)" : T.bgPrimary) : T.textSecondary, fontWeight: 400 }}>{sub}</span>}
    </button>
  );
}

// ── SectionLabel ──────────────────────────────────────────────────────────
function SectionLabel({ children, style }) {
  return (
    <div style={{
      fontSize: 10,
      color: T.textSecondary,
      letterSpacing: "0.12em",
      textTransform: "uppercase",
      fontFamily: "monospace",
      marginBottom: 6,
      ...style,
    }}>{children}</div>
  );
}

// ── Divider ──────────────────────────────────────────────────────────────
function Divider({ vertical, style }) {
  return vertical
    ? <div style={{ width: 1, background: T.border, alignSelf: "stretch", ...style }} />
    : <div style={{ height: 1, background: T.border, ...style }} />;
}

// ── WarnBadge ──────────────────────────────────────────────────────────────
function WarnBadge({ level }) {
  if (!level) return null;
  const color = level >= 2 ? T.statusCrit : T.statusWarn;
  return (
    <span style={{
      background: color + "22",
      border: `1px solid ${color}`,
      color,
      fontSize: 9,
      fontFamily: "monospace",
      fontWeight: 700,
      letterSpacing: "0.06em",
      padding: "1px 5px",
      borderRadius: 2,
    }}>{level >= 2 ? "CRIT" : "WARN"}</span>
  );
}

// ── ProgressBar ──────────────────────────────────────────────────────────
function ProgressBar({ value, max = 100, color, style }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const c = color || (pct > 60 ? T.statusOk : pct > 25 ? T.statusWarn : T.statusCrit);
  return (
    <div style={{ height: 4, background: T.bgSecondary, borderRadius: 2, overflow: "hidden", ...style }}>
      <div style={{ width: `${pct}%`, height: "100%", background: c, borderRadius: 2, transition: "width 0.3s" }} />
    </div>
  );
}

// ── AttitudeIndicator ──────────────────────────────────────────────────────
function AttitudeIndicator({ pitch = 0, roll = 0, size = 120 }) {
  const r = size / 2;
  const pixPerDeg = r / 45;
  const pitchOffset = pitch * pixPerDeg;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: "block" }}>
      <defs>
        <clipPath id="ai-clip">
          <circle cx={r} cy={r} r={r - 2} />
        </clipPath>
      </defs>
      <g clipPath="url(#ai-clip)" transform={`rotate(${-roll} ${r} ${r})`}>
        {/* Sky */}
        <rect x={0} y={0} width={size} height={r + pitchOffset} fill="#1a3a5c" />
        {/* Ground */}
        <rect x={0} y={r + pitchOffset} width={size} height={size} fill="#3a2010" />
        {/* Horizon line */}
        <line x1={0} y1={r + pitchOffset} x2={size} y2={r + pitchOffset} stroke="#aaa" strokeWidth={1} />
        {/* Pitch lines */}
        {[-20, -10, 10, 20].map(d => (
          <line key={d}
            x1={r - 18} y1={r + pitchOffset - d * pixPerDeg}
            x2={r + 18} y2={r + pitchOffset - d * pixPerDeg}
            stroke="rgba(255,255,255,0.4)" strokeWidth={1}
          />
        ))}
      </g>
      {/* Outer ring */}
      <circle cx={r} cy={r} r={r - 2} fill="none" stroke={T.border} strokeWidth={2} />
      {/* Fixed aircraft symbol */}
      <line x1={r - 30} y1={r} x2={r - 12} y2={r} stroke={T.accentYellow} strokeWidth={2} />
      <line x1={r + 12} y1={r} x2={r + 30} y2={r} stroke={T.accentYellow} strokeWidth={2} />
      <circle cx={r} cy={r} r={3} fill={T.accentYellow} />
    </svg>
  );
}

// ── HeadingTape ──────────────────────────────────────────────────────────
function HeadingTape({ heading = 0, width = 300, height = 36 }) {
  const degPerPx = 0.5;
  const ticks = [];
  for (let d = -60; d <= 60; d += 5) {
    const hdg = ((heading + d) % 360 + 360) % 360;
    const x = width / 2 + d / degPerPx;
    const isMajor = hdg % 30 === 0;
    ticks.push(
      <g key={d}>
        <line x1={x} y1={0} x2={x} y2={isMajor ? 14 : 8} stroke={T.border} strokeWidth={isMajor ? 1.5 : 1} />
        {isMajor && (
          <text x={x} y={26} textAnchor="middle" fill={T.textSecondary} fontSize={9} fontFamily="monospace">
            {hdg === 0 ? "N" : hdg === 90 ? "E" : hdg === 180 ? "S" : hdg === 270 ? "W" : hdg}
          </text>
        )}
      </g>
    );
  }
  return (
    <svg width={width} height={height} style={{ display: "block", overflow: "hidden" }}>
      <rect width={width} height={height} fill={T.bgSecondary} />
      {ticks}
      {/* Center marker */}
      <polygon points={`${width / 2},${height - 2} ${width / 2 - 5},${height - 10} ${width / 2 + 5},${height - 10}`} fill={T.accentYellow} />
    </svg>
  );
}

// ── AltitudeTape ──────────────────────────────────────────────────────────
function AltitudeTape({ altitude = 0, width = 48, height = 120 }) {
  const mPerPx = 2;
  const ticks = [];
  for (let d = -60; d <= 60; d += 5) {
    const alt = altitude + d * mPerPx;
    const y = height / 2 - d;
    const isMajor = Math.round(alt / 10) * 10 === Math.round(alt);
    if (isMajor) ticks.push(
      <g key={d}>
        <line x1={width - 8} y1={y} x2={width} y2={y} stroke={T.border} strokeWidth={1} />
        <text x={width - 10} y={y + 4} textAnchor="end" fill={T.textSecondary} fontSize={9} fontFamily="monospace">
          {Math.round(alt / 10) * 10}
        </text>
      </g>
    );
  }
  return (
    <svg width={width} height={height} style={{ display: "block" }}>
      <rect width={width} height={height} fill={T.bgSecondary} />
      {ticks}
      <rect x={0} y={height / 2 - 10} width={width} height={20} fill={T.bgElevated} />
      <text x={width / 2} y={height / 2 + 5} textAnchor="middle" fill={T.textPrimary} fontSize={12} fontWeight="bold" fontFamily="monospace">
        {Math.round(altitude)}
      </text>
    </svg>
  );
}

// ── CompassRose ──────────────────────────────────────────────────────────
function CompassRose({ heading = 0, size = 120 }) {
  const cx = size / 2, cy = size / 2, r = size / 2 - 4;
  const toRad = d => (d - 90) * Math.PI / 180;
  const cardinals = ["N","NE","E","SE","S","SW","W","NW"];
  return (
    <svg width={size} height={size} style={{ display: "block" }}>
      <circle cx={cx} cy={cy} r={r} fill={T.bgSecondary} stroke={T.border} strokeWidth={1} />
      {cardinals.map((c, i) => {
        const ang = i * 45;
        const rad = toRad(ang);
        const tx = cx + (r - 14) * Math.cos(rad);
        const ty = cy + (r - 14) * Math.sin(rad);
        return <text key={c} x={tx} y={ty + 4} textAnchor="middle" fill={c === "N" ? T.accentYellow : T.textSecondary} fontSize={c.length === 1 ? 11 : 8} fontFamily="monospace" fontWeight={c === "N" ? 700 : 400}>{c}</text>;
      })}
      {/* Heading arrow */}
      <g transform={`rotate(${heading} ${cx} ${cy})`}>
        <polygon points={`${cx},${cy - r + 8} ${cx - 5},${cy} ${cx + 5},${cy}`} fill={T.accentYellow} />
      </g>
      <circle cx={cx} cy={cy} r={3} fill={T.textPrimary} />
    </svg>
  );
}

// ── MapView placeholder ──────────────────────────────────────────────────
function MapPlaceholder({ lat = 52.374, lon = 4.893, width = "100%", height = "100%", droneLat, droneLon }) {
  return (
    <div style={{ width, height, background: "#0d1a12", border: `1px solid ${T.border}`, borderRadius: 4, position: "relative", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
      {/* Grid lines */}
      {[...Array(8)].map((_, i) => (
        <React.Fragment key={i}>
          <div style={{ position: "absolute", left: `${i * 12.5}%`, top: 0, bottom: 0, width: 1, background: "rgba(74,90,74,0.3)" }} />
          <div style={{ position: "absolute", top: `${i * 12.5}%`, left: 0, right: 0, height: 1, background: "rgba(74,90,74,0.3)" }} />
        </React.Fragment>
      ))}
      <div style={{ textAlign: "center", fontFamily: "monospace", color: T.textDisabled, fontSize: 11, lineHeight: 1.8, userSelect: "none" }}>
        <div style={{ fontSize: 13, color: T.textSecondary, marginBottom: 4 }}>MAP VIEW</div>
        <div>{lat.toFixed(4)}° N</div>
        <div>{lon.toFixed(4)}° E</div>
      </div>
      {/* Drone marker */}
      <div style={{ position: "absolute", left: "50%", top: "45%", transform: "translate(-50%,-50%)" }}>
        <svg width={20} height={20}>
          <circle cx={10} cy={10} r={8} fill="none" stroke={T.accentYellow} strokeWidth={1.5} />
          <circle cx={10} cy={10} r={3} fill={T.accentYellow} />
          <line x1={10} y1={2} x2={10} y2={7} stroke={T.accentYellow} strokeWidth={1.5} />
        </svg>
      </div>
    </div>
  );
}

// Export all
Object.assign(window, {
  T,
  StatusDot,
  DataCard,
  SmallDataCard,
  BigButton,
  SectionLabel,
  Divider,
  WarnBadge,
  ProgressBar,
  AttitudeIndicator,
  HeadingTape,
  AltitudeTape,
  CompassRose,
  MapPlaceholder,
});
